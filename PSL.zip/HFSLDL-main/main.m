clc; clear;
% str1={'DD';'F194';'CLEF'};
str1={'DD'};
% str1={'DD';'F194';'CLEF';'VOC';'ILSVRC65';'Sun';'Cifar100';};
a=[0.05,0.5,0.2];
b=[0.05,0.15,0.15];
m = length(str1);
rng('default');
for i =1:m
    indx=[];
    filename = [str1{i} 'Train']    
    %     filename1 = [str1{i} 'cor1']
    load (filename);
    %     load (filename1);
    %Pearson similarity
    
    %%%%%%%%%
     %%%%%%%%%%%%

    Method=0;
    K_l=2;k_s=0.9;
    [new_trees,data_array2] = number_clus(data_array,K_l,k_s,str1{i});
    tree=new_trees;
%     treeplot(new_trees(:,1)');
%     title(str1);
    data_array=data_array2;

    %%%%%%%%%%%%
    %%%%%%%%%%%%
    cor=corr(data_array(:,1:end-1)',data_array(:,1:end-1)','type','pearson');   
    [X,Y,~,cor]=create_SubTable(data_array, tree,cor);
    tic;
%     [Yd] = create_hier_distribution(Y,tree,cor,0,0);
    [Yd] = create_hier_distribution(Y,tree,cor,a(1),b(1));
    [treecor] = get_treecor(tree);
    [sibcor] = get_sibcor(cor,Y,tree);
    %Feature selection

      [feature_slct,W] = HFSLDL(X, Yd, tree, 10, treecor,sibcor,0.1,0.1,0);

    count_num=tabulate(data_array(:,end));
    max_num=max(count_num(:,2));
    mon_num=max_num*0.2;
    mon_index{i}=find(count_num(:,2)<=mon_num);
    %Test feature batch
    testFile = [str1{i}, 'Test.mat']
    load (testFile);
    %%%%%%%%%%
    tree=new_trees;
    %%%%%%%%%%%
    [accuracyMean(i), accuracyStd(i), F_LCAMean(i), FHMean(i), TIEmean(i), TestTime(i),accuracy_l{i},accuracy_mon(i),FHStd(i), TIEStd(i),accuracy_monStd(i),FH{i},TIE{i}] = HierSVMPredictionBatch(data_array, tree, feature_slct,mon_index{i},str1{i},Method);        %
    [t_r,~]=size(data_array);
    tiemean(i)=TIEmean(i)/t_r;
    tieStd(i)=TIEStd(i)./t_r;
    tie{i}=TIE{i}./t_r;
    FSTime(i) =toc;
end
