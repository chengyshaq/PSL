function index = tree_Root( tree )
% reture the root of the tree
% May 16th, 2017 
   tree = tree(:,1);
  index=find(tree==0);
   
end

