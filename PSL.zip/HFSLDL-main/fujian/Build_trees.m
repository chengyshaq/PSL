function [trees]= Build_trees (count_num,K,data_array,label_cell,q)
count=count_num(:,2);
a=length(count);
tree=[];
allnum=sum(count);
epss=1;
num_clusters=K;
c=0;
label_clusters = cluster(data_array,1, num_clusters,label_cell,q);
for i=1:K
    node_dex=[];
    node_dex=find(label_clusters==i);
    if length(node_dex)>1;
        c=c+1;
        count(real(a+c),1)=sum(count(node_dex,1));
        tree(node_dex,1)=real(a+c);
        count(node_dex,1)=inf;
    end
end
for j=1:10000
    if epss<allnum-1
        [~, sorted_indices] = sort(count);
        epss=sum(count(sorted_indices(1:K,1),1));
        c=c+1;
        count(real(a+j),1)=sum(count(sorted_indices(1:K,1),1));
        tree(sorted_indices(1:K,1),1)=real(a+c);
        count(sorted_indices(1:K,1),1)=inf;
    else
        break;
    end
    
end
% find(tree(:,1)==3)
b=length(tree);
tree(b+1,1)=0;
tree(b+1,2)=0;
leval=0;
nodes=b+1;
D = [];
while (nodes~=0)
    leval=leval+1;
    nnodes = [];
    for k = 1 : length(nodes)
        nnodes = [nnodes; find(tree(:,1)==nodes(k))];%�ҵ�tree��Ϊ��ǰ�ڵ��λ���������� 1 2 3 4 5 6��Ϊ28
    end
    D = [D; nnodes];
    nodes = nnodes; %�ٽ�������ڵ������ֱ���ҵ���������ڵ�
    tree(nnodes,2)=leval;
end
c=length(D);
%leval=ceil(c./K)+1;
%     tree(i,2)=leval;

% tree(b+1,1)=0;
% tree(b+1,2)=0;
trees=tree;
end