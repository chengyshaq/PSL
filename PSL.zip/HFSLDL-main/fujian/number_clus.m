% clc;clear;
% load 'DDTrain';
function [new_trees,data_array2] = number_clus(data_array,K_l,k_s,q)

[label_cell] = label_class( data_array);
[m, n] = size(label_cell);
label_cell2 = cell(m, 1);


for i = 1:m
    data = label_cell(i,:);
     [a, b]=size(cell2mat(data));
    kk=round(size(cell2mat(data),1)*1);
    [ntl,label_cell2{i},data_array2]=kmeans(cell2mat(data),round(size(cell2mat(data),1)*k_s),'EmptyAction','singleton','OnlinePhase','off','Display','off');
%%%%%%%%%%%%%%%%%%%%%%%%%%��ɢ��ͼ
%     data=cell2mat(data);
%     figure;
%     scatter(data(:,1), data(:,2), 10, 'r', 'filled', 'o');
%     hold on;
%     % ������������
%     scatter(label_cell2{i}(:,1), label_cell2{i}(:,2), 50, 'b', 'filled', 'o');
%     hold off;
 %%%%%%%%%%%%%%%%%%%%%%%     
    %     is_included = any(mon_index == i); 
%     if is_included
%         k_s2=k_s*0.2;
%     else
%         k_s2=k_s*1;
%     end
%  [ntl,label_cell2{i}]=kmeans(cell2mat(data),round(size(cell2mat(data),1)*k_s2),'EmptyAction','singleton','OnlinePhase','off','Display','off');

%%%%%@@@@@!!!

%%%%%%%%%@@@!!!!!
end
    
    data_array2=cell2mat(label_cell2);
    count_num=tabulate(data_array2(:,end));
    new_trees=Build_trees(count_num,K_l,data_array2,label_cell,q);
%     new_trees=Build_trees2(count_num,K_l,data_array2);

end
