%% creatSubTable
% Written by Yu Wang
% Modified by Hong Zhao
% Modified by Haoyang Liu
%% Creat subtable
function [DataMod,LabelMod,IndxMod,CorMod]=create_SubTablezh(dataset, tree,cor)
Data = dataset(:,1:end-1);
Label =  dataset(:,end);
[numTrain,~] = size(dataset);
internalNodes = tree_InternalNodes(tree);
leafNode=tree_LeafNode(tree);
internalNodes(find(internalNodes==-1))=[];
indexRoot = tree_Root(tree);% The root of the tree
noLeafNode =[internalNodes;indexRoot];
for i = 1:length(noLeafNode)
    cur_descendants = tree_Descendant(tree, noLeafNode(i));
    ind_d = 1;  % index for id subscript increment
    id = [];        % data whose labels belong to the descendants of the current nodes
    for n = 1:numTrain
        if (ismember(Label(n), cur_descendants) ~= 0)
            id(ind_d) =  n;
            ind_d = ind_d +1;
        end
    end
    Label_Uni_Sel = Label(id,:);
    DataSel = Data(id,:);     %select relative training data for the current classifier
    CorSel=cor(id,id);
    numTrainSel = size(Label_Uni_Sel,1);
    LabelUniSelMod = mylabel_modify_MLNP(Label_Uni_Sel, noLeafNode(i), tree);%% 
    % Get the sub-training set containing only relative nodes
    ind_tdm = 1;
    index = [];     % data whose labels belong to the children of the current nodes
    children_set = get_children_set(tree, noLeafNode(i));
    for ns = 1:numTrainSel
        if (ismember(LabelUniSelMod(ns), children_set) ~= 0)
            index(ind_tdm) =  ns;
            ind_tdm = ind_tdm +1;
        end
    end
    DataMod{noLeafNode(i)} = DataSel(index, :);   % Find the sub training set of relative to-be-classified nodes
    LabelMod{noLeafNode(i)} = LabelUniSelMod(index, :);
    IndxMod{noLeafNode(i)} = id;
    CorMod{noLeafNode(i)} = CorSel(index, index); 
end
% a=1;
% for i = 1:length(leafNode)
%     ind_d2=1;
%     id2=[];
%     for j = 1:length(internalNodes)
%     cur_descendants2 = tree_Descendant(tree, internalNodes(j));
%     for n = 1:numTrain
%         if (ismember(Label(n), cur_descendants2) == 0 && Label(n)==i)
%             id2(ind_d2) =  n;
%             ind_d2 = ind_d2 +1;
%         end
%     end
%     DataMod{i}=dataset(id2, 1:end-1);
% %     DataMod{i} = DataSel(id2, :);   % Find the sub training set of relative to-be-classified nodes
%     LabelMod{i} = LabelUniSelMod(id2, :);
% %     IndxMod{noLeafNode(i)} = id;
%     CorMod{i} = CorSel(id2, id2);
%     end
% end
end